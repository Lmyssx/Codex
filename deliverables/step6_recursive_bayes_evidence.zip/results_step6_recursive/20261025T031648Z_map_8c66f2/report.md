calibration_missing: no real thickness inference performed.
