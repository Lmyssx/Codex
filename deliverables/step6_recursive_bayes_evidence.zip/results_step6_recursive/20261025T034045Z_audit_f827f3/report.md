Command: audit

Status: audit_only

See command_status.json / audit.json / validation.json for measured evidence.
No real human thickness or accuracy claim. Missing raw MAT, calibration and labels are tracked separately.
