Status: synthetic_generated

See STEP6_IMPLEMENTATION_REPORT_zh.md and run_registry.json for acceptance and superseded runs.
No real human thickness estimate.
