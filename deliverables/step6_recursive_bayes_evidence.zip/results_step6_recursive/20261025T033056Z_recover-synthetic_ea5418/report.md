Status: posterior_multimodal

Synthetic experiment only. No human accuracy claim. Cold chains only.
Rank Rhat / bulk ESS / tail ESS include s2. Smoke never counts as converged validation.
Predictive bands show conditional mean response; measurement noise and unmodeled errors require separate checks.
